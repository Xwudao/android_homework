<?php
require './vendor/autoload.php';


// 定义核心
define('MC_CORE', true);

// 定义版本
define('MC_VERSION', '1.6.2');

// 核心文件目录
define('MC_CORE_DIR', __DIR__ . '/core');

// 模版文件目录
define('MC_TEMP_DIR', __DIR__ . '/template');

// 调试模式，0为关闭，-1为打开
define('MC_DEBUG', 0);

// Curl 代理地址，例如：define('MC_PROXY', 'someproxy.com:9999')
define('MC_PROXY', false);

// Curl 代理用户名和密码，例如：define('MC_PROXYUSERPWD', 'username:password')
define('MC_PROXYUSERPWD', false);

// 服务器是否在国内
define('MC_INTERNAL', 1);


include 'core/core.php';
$kw = $_REQUEST['kw'] ?? '逆流成河';
echo json_encode(mc_get_song_by_name($kw));